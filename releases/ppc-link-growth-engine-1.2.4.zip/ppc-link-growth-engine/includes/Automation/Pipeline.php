<?php
/**
 * Orchestrates automation stages: cadence-based enqueueing, direct runs and status.
 *
 * @package PPC\LinkGrowth
 */

declare(strict_types=1);

namespace PPC\LinkGrowth\Automation;

use PPC\LinkGrowth\Automation\Jobs\EvaluateJob;
use PPC\LinkGrowth\Container;
use PPC\LinkGrowth\Discovery\VerifiedOpportunities;
use PPC\LinkGrowth\Growth\GrowthRun;
use PPC\LinkGrowth\Monitoring\Notifier;
use PPC\LinkGrowth\Outreach\Compliance;
use PPC\LinkGrowth\Outreach\OutreachEngine;
use PPC\LinkGrowth\Repositories\Backlinks;
use PPC\LinkGrowth\Repositories\Jobs;
use PPC\LinkGrowth\Repositories\Prospects;
use PPC\LinkGrowth\Repositories\Submissions;
use PPC\LinkGrowth\Seo\IndexNow;
use PPC\LinkGrowth\Support\Limits;
use PPC\LinkGrowth\Support\Logger;
use PPC\LinkGrowth\Support\Settings;
use PPC\LinkGrowth\Support\TimeBudget;
use Throwable;

final class Pipeline {

    public const OPTION_LAST_TICK  = 'ppclg_last_tick';
    public const OPTION_STAGE_RUNS = 'ppclg_stage_runs';

    /** Who had the last tick that both a background growth run and due queued jobs wanted: 'growth' | 'queue'. */
    public const OPTION_GROWTH_TURN = 'ppclg_growth_turn';

    /** Per-stage automation flags exposed in status(). */
    public const FLAGS = [ 'discovery', 'evaluation', 'opportunities', 'packaging', 'submissions', 'outreach_autosend', 'monitoring', 'imports' ];

    /** Stale "running" jobs older than this are re-queued on every tick. */
    private const STALE_SECONDS = 900;

    public function __construct(
        private Jobs $jobs,
        private JobRunner $runner,
        private Settings $settings,
        private Limits $limits,
        private Logger $logger,
        private ?LoadGuard $guard = null
    ) {}

    /**
     * One scheduler tick: continue an active growth run whose browser tab went away, enqueue due stages (when
     * automation is enabled) and run the queue.
     *
     * While the server is under pressure (LoadGuard: OPcache restarting, a backup running, the plugin just updated,
     * the load above 2 per CPU, less than 10 % of the memory available, or the ppclg_pause_background filter) the
     * tick does nothing else: no job is claimed, no stage is enqueued, no
     * growth step runs and no limit is spent; it returns skipped_reason "paused" with the reason, which is logged and
     * stored once per pause. The first tick after the pause logs the resume and works as usual.
     *
     * @return array{enqueued:string[],run:array{ran:int,completed:int,failed:int,skipped:bool},skipped_reason:string,growth:?array<string,mixed>,paused:?array<string,mixed>}
     */
    public function tick(): array {
        update_option( self::OPTION_LAST_TICK, gmdate( 'c' ), false );
        $out = [
            'enqueued'       => [],
            'run'            => [ 'ran' => 0, 'completed' => 0, 'failed' => 0, 'skipped' => false ],
            'skipped_reason' => '',
            'growth'         => null,
            'paused'         => null,
        ];

        // Asked afresh on every tick; the growth run and kicks in the same request reuse this answer.
        $paused = null;
        try {
            $guard         = $this->loadGuard();
            $paused        = $guard->pauseReason( true );
            $out['paused'] = $guard->track( $paused, $this->logger );
        } catch ( Throwable $e ) {
            $paused = null; // a guard that cannot answer never stops the tick
        }
        if ( null !== $paused ) {
            $out['skipped_reason'] = 'paused';
            return $out;
        }

        try {
            $recovered = $this->jobs->recoverStale( self::STALE_SECONDS );
            if ( $recovered > 0 ) {
                $this->logger->warning( 'automation', 'Recovered stale running jobs', [ 'count' => $recovered ] );
            }
        } catch ( Throwable $e ) {
            $this->logger->error( 'automation', 'Stale job recovery failed: ' . $e->getMessage() );
        }

        // A growth run is the owner's explicit click, so it continues even while the automation switch is off. It
        // shares the tick's budget with the queue run below, so one tick never runs longer than the ceiling. An
        // advance uses nearly all of that budget, so while other jobs are due the run and the queue take turns:
        // after a tick that advanced the run, the next one gives the queue (sends, follow-ups, monitoring) a full
        // budget, and the run continues on the tick after that.
        $automation = (bool) $this->settings->get( 'automation.enabled', false );
        $budget     = TimeBudget::seconds( $this->maxSeconds() );
        if ( $this->queueTurn( $automation ) ) {
            $out['growth']      = null;
            $out['growth_turn'] = 'queue';
        } else {
            $out['growth'] = $this->continueGrowthRun( $budget );
            if ( null !== $out['growth'] && ! empty( $out['growth']['advanced'] ) ) {
                $this->setTurn( 'growth' );
            }
        }
        if ( null === $out['growth'] ) {
            $budget = null; // nothing ran: the queue gets a fresh, full budget (created when it starts)
        }

        if ( $automation ) {
            $out['enqueued'] = $this->enqueueDueStages();
        } else {
            $out['skipped_reason'] = 'automation_disabled';
            $this->cancelAutomaticQueued();
            if ( ! $this->hasQueuedManual() ) {
                return $out;
            }
        }

        try {
            $out['run'] = $this->runner->run( $budget ?? TimeBudget::seconds( $this->maxSeconds() ) );
        } catch ( Throwable $e ) {
            $this->logger->error( 'automation', 'Job runner crashed: ' . $e->getMessage() );
        }
        if ( ! empty( $out['run']['skipped'] ) && '' === $out['skipped_reason'] ) {
            $out['skipped_reason'] = 'runner_busy';
        }
        return $out;
    }

    /**
     * Enqueues a stage unless an identical job is already queued/running.
     *
     * @param array<string,mixed> $payload
     */
    public function enqueueStage( string $type, array $payload = [], int $priority = 5, bool $manual = false ): ?int {
        if ( ! isset( $this->runner->types()[ $type ] ) ) {
            $this->logger->warning( 'automation', 'Refusing to enqueue unknown job type', [ 'type' => $type ] );
            return null;
        }
        if ( $manual ) {
            $payload['manual'] = true;
        }
        try {
            $pending = [] === $payload ? $this->jobs->hasPending( $type ) : $this->jobs->hasPending( $type, $payload );
            if ( $pending ) {
                return null;
            }
            $id = $this->jobs->enqueue( $type, $payload, $priority );
        } catch ( Throwable $e ) {
            $this->logger->error( 'automation', 'Could not enqueue stage: ' . $e->getMessage(), [ 'type' => $type ] );
            return null;
        }
        $this->logger->debug( 'automation', 'Stage enqueued', [ 'type' => $type, 'job_id' => $id, 'manual' => $manual, 'priority' => $priority ] );
        return $id;
    }

    /**
     * Runs a stage immediately under the runner lock; queues it (priority 1) when the runner is busy.
     *
     * @param array<string,mixed> $payload
     * @return array{result:array<string,mixed>,job_id:?int}
     */
    public function runNow( string $type, array $payload, float $seconds ): array {
        if ( ! isset( $this->runner->types()[ $type ] ) ) {
            return [ 'result' => [ 'ok' => false, 'error' => sprintf( 'Unknown job type "%s".', $type ) ], 'job_id' => null ];
        }
        $payload['manual'] = true;
        $seconds           = max( 1.0, min( 120.0, $seconds ) );

        if ( ! $this->runner->lock( (int) ceil( $seconds ) + 60 ) ) {
            $id = $this->enqueueStage( $type, $payload, 1, true );
            return [
                'result' => [
                    'ok'        => true,
                    'queued'    => true,
                    'duplicate' => null === $id,
                    'message'   => null === $id
                        ? 'The job runner is busy and this job is already queued; it will run on the next tick.'
                        : 'The job runner is busy; the job has been queued with top priority and will run on the next tick.',
                ],
                'job_id' => $id,
            ];
        }

        try {
            $result = $this->runner->runType( $type, $payload, TimeBudget::seconds( $seconds ) );
        } finally {
            $this->runner->unlock();
        }
        $this->recordStageRun( $type );
        try {
            $this->container()->get( Audit::class )->record(
                'automation.run_now',
                'job',
                0,
                [ 'type' => $type, 'payload' => $payload, 'ok' => (bool) ( $result['ok'] ?? true ), 'elapsed' => $result['elapsed'] ?? null ]
            );
        } catch ( Throwable $e ) {
            unset( $e );
        }
        return [ 'result' => $result, 'job_id' => null ];
    }

    /**
     * @return array<string,mixed>
     */
    public function status(): array {
        $flags = [];
        foreach ( self::FLAGS as $flag ) {
            $flags[ $flag ] = (bool) $this->settings->get( 'automation.' . $flag, false );
        }
        $stages = [];
        foreach ( $this->stages() as $type => $stage ) {
            $stages[ $type ] = [
                'priority' => $stage['priority'],
                'cadence'  => $stage['cadence'],
                'flag'     => $stage['flag'],
            ];
        }
        $queue = [];
        $recent = [];
        try {
            $queue  = $this->jobs->statusCounts();
            $recent = $this->jobs->findBy( [], 'id', 'DESC', 20 );
        } catch ( Throwable $e ) {
            $this->logger->error( 'automation', 'Could not read job queue: ' . $e->getMessage() );
        }
        $lastTick = get_option( self::OPTION_LAST_TICK, '' );
        $results  = get_option( JobRunner::OPTION_STAGE_RESULTS, [] );
        $paused   = null;
        try {
            $paused = $this->loadGuard()->status();
        } catch ( Throwable $e ) {
            unset( $e );
        }

        return [
            'automation_enabled'    => (bool) $this->settings->get( 'automation.enabled', false ),
            'flags'                 => $flags,
            // What the stages actually use: Autopilot raises submissions / outreach autosend / auto drafts to on.
            'effective_flags'       => $this->effectiveFlags(),
            'autopilot'             => $this->autopilot()->isOn(),
            'queue'                 => $queue,
            'last_tick'             => is_string( $lastTick ) && '' !== $lastTick ? $lastTick : null,
            'stage_runs'            => $this->stageRuns(),
            'stage_results'         => is_array( $results ) ? $results : [],
            'stages'                => $stages,
            'limits'                => $this->limits->snapshot(),
            'recent_jobs'           => $recent,
            'locked'                => $this->runner->isLocked(),
            'max_execution_seconds' => $this->maxSeconds(),
            'tick_interval'         => max( 60, (int) $this->settings->get( 'automation.tick_interval', 300 ) ),
            // Background work paused because the server is under pressure: {code, message, text, until, since,
            // source}, e.g. text "Paused: a backup is running (resumes automatically)."; null while it runs.
            'paused'                => $paused,
        ];
    }

    /** The server-pressure guard (the container's, so a request asks it once). */
    public function loadGuard(): LoadGuard {
        if ( null === $this->guard ) {
            try {
                $svc = $this->container()->get( LoadGuard::class );
                $this->guard = $svc instanceof LoadGuard ? $svc : new LoadGuard();
            } catch ( Throwable $e ) {
                $this->guard = new LoadGuard();
            }
        }
        return $this->guard;
    }

    /** Cancels queued jobs (optionally of one type). */
    public function cancelQueued( ?string $type = null ): int {
        $n = $this->jobs->cancelQueued( $type );
        $this->logger->info( 'automation', 'Queued jobs cancelled', [ 'type' => $type ?? '(all)', 'count' => $n ] );
        try {
            $this->container()->get( Audit::class )->record( 'automation.cancel_queued', 'job', 0, [ 'type' => $type, 'count' => $n ] );
        } catch ( Throwable $e ) {
            unset( $e );
        }
        return $n;
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    /**
     * True when this tick belongs to the queue: the previous tick advanced a background growth run and queued jobs
     * that this tick would run are due (any due job with automation on, manual ones with automation off).
     */
    private function queueTurn( bool $automation ): bool {
        if ( 'growth' !== get_option( self::OPTION_GROWTH_TURN, '' ) ) {
            return false;
        }
        $this->setTurn( 'queue' );
        return $this->hasDueQueued( ! $automation );
    }

    private function setTurn( string $turn ): void {
        if ( get_option( self::OPTION_GROWTH_TURN, '' ) !== $turn ) {
            update_option( self::OPTION_GROWTH_TURN, $turn, false );
        }
    }

    /** Whether a queued job is due now (only manual ones when $manualOnly). */
    private function hasDueQueued( bool $manualOnly ): bool {
        try {
            $now = gmdate( 'Y-m-d H:i:s' );
            foreach ( $this->jobs->findBy( [ 'status' => Jobs::STATUS_QUEUED ], 'scheduled_at', 'ASC', 200 ) as $job ) {
                if ( (string) ( $job['scheduled_at'] ?? '' ) > $now ) {
                    continue;
                }
                $payload = is_array( $job['payload'] ?? null ) ? $job['payload'] : [];
                if ( ! $manualOnly || ! empty( $payload['manual'] ) ) {
                    return true;
                }
            }
        } catch ( Throwable $e ) {
            unset( $e );
        }
        return false;
    }

    /**
     * Advances an active growth run (Growth\GrowthRun) with this tick's budget when nobody advanced it for more
     * than GrowthRun::BACKGROUND_AFTER_SECONDS (the dashboard tab was closed). Never lets a failure break the tick.
     *
     * @return array<string,mixed>|null null when there was nothing to continue.
     */
    private function continueGrowthRun( TimeBudget $budget ): ?array {
        try {
            if ( ! class_exists( GrowthRun::class ) ) {
                return null;
            }
            $run = $this->container()->get( GrowthRun::class );
            if ( ! $run instanceof GrowthRun || ! $run->isActive() || $run->lastAdvanceAge() <= GrowthRun::BACKGROUND_AFTER_SECONDS ) {
                return null;
            }
            $state = $run->advance( $budget );
            return [
                'advanced' => empty( $state['waiting'] ),
                'id'       => (string) ( $state['id'] ?? '' ),
                'status'   => (string) ( $state['status'] ?? '' ),
                'cursor'   => (int) ( $state['cursor'] ?? 0 ),
            ];
        } catch ( Throwable $e ) {
            try {
                $this->logger->error( 'growth', 'The growth run could not be continued in the background: ' . $e->getMessage() );
            } catch ( Throwable $ignored ) {
                unset( $ignored );
            }
            return null;
        }
    }

    /**
     * Stage definitions: cadence in seconds (0 = every tick, subject to the optional due-check),
     * governing automation flag ('' = none) and priority from the job class.
     *
     * @return array<string,array{every:int,flag:string,due:?string,priority:int,cadence:string}>
     */
    private function stages(): array {
        $importDays = max( 1, (int) $this->settings->get( 'monitoring.import_interval_days', 7 ) );
        // Automatic internal links (seo.auto_apply_links or Autopilot) run daily so the daily cap is used.
        $autoLinks  = (bool) $this->settings->get( 'seo.internal_links', true ) && $this->autopilot()->autoApplyLinks();
        $defs       = [
            'discover'           => [ 'every' => DAY_IN_SECONDS, 'flag' => 'discovery', 'due' => null, 'cadence' => 'daily' ],
            'mention_scan'       => [ 'every' => WEEK_IN_SECONDS, 'flag' => 'discovery', 'due' => null, 'cadence' => 'weekly' ],
            'evaluate'           => [ 'every' => 0, 'flag' => 'evaluation', 'due' => 'evaluateDue', 'cadence' => 'every tick (when prospects are due)' ],
            'find_opportunities' => [ 'every' => 0, 'flag' => 'opportunities', 'due' => 'opportunitiesDue', 'cadence' => 'every tick (when qualified prospects lack opportunities)' ],
            'storefront_audit'   => [ 'every' => DAY_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'daily (and when products, product categories/tags or menus change)' ],
            'import_verified'    => [ 'every' => 0, 'flag' => '', 'due' => 'verifiedImportDue', 'cadence' => 'when the bundled verified opportunity data changes' ],
            'package'            => [ 'every' => HOUR_IN_SECONDS, 'flag' => 'packaging', 'due' => null, 'cadence' => 'hourly' ],
            'submit'             => [ 'every' => 0, 'flag' => 'submissions', 'due' => 'submitDue', 'cadence' => 'every tick (when approved submissions are queued)' ],
            'verify_listings'    => [ 'every' => 6 * HOUR_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'every 6 hours' ],
            'outreach_send'      => [ 'every' => 0, 'flag' => '', 'due' => 'outreachDue', 'cadence' => 'every tick inside the send window (when approved messages are ready)' ],
            'auto_outreach'      => [ 'every' => DAY_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'daily' ],
            'follow_ups'         => [ 'every' => DAY_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'daily' ],
            'monitor_backlinks'  => [ 'every' => 0, 'flag' => 'monitoring', 'due' => 'monitorDue', 'cadence' => 'every tick (when backlinks are due)' ],
            'import_backlinks'   => [ 'every' => $importDays * DAY_IN_SECONDS, 'flag' => 'imports', 'due' => null, 'cadence' => sprintf( 'every %d days', $importDays ) ],
            'cleanup'            => [ 'every' => DAY_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'daily' ],
            'metrics_refresh'    => [ 'every' => WEEK_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'weekly' ],
            'site_audit'         => [ 'every' => DAY_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'daily' ],
            'indexnow'           => [ 'every' => HOUR_IN_SECONDS, 'flag' => '', 'due' => 'indexnowDue', 'cadence' => 'hourly (when URLs are waiting)' ],
            'internal_links'     => $autoLinks
                ? [ 'every' => DAY_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => sprintf( 'daily (applies up to %d links automatically)', $this->autopilot()->linksPerDay() ) ]
                : [ 'every' => WEEK_IN_SECONDS, 'flag' => '', 'due' => null, 'cadence' => 'weekly (suggestions only)' ],
        ];
        $types = $this->runner->types();
        $out   = [];
        foreach ( $defs as $type => $def ) {
            if ( ! isset( $types[ $type ] ) ) {
                continue;
            }
            $def['priority'] = max( 1, min( 9, (int) $types[ $type ]::priority() ) );
            $out[ $type ]    = $def;
        }
        // Registered-but-unscheduled types (e.g. broken_link_scan, custom ones) are still listed for the dashboard.
        foreach ( $types as $type => $class ) {
            if ( ! isset( $out[ $type ] ) ) {
                $out[ $type ] = [ 'every' => -1, 'flag' => '', 'due' => null, 'cadence' => 'manual', 'priority' => max( 1, min( 9, (int) $class::priority() ) ) ];
            }
        }
        return $out;
    }

    /** @return string[] enqueued types */
    private function enqueueDueStages(): array {
        $enqueued = [];
        $runs     = $this->stageRuns();
        $now      = time();
        foreach ( $this->stages() as $type => $stage ) {
            if ( $stage['every'] < 0 ) {
                continue; // manual-only
            }
            try {
                if ( '' !== $stage['flag'] && ! $this->autopilot()->flag( $stage['flag'] ) ) {
                    continue;
                }
                $last = isset( $runs[ $type ] ) ? (int) strtotime( (string) $runs[ $type ] ) : 0;
                if ( $stage['every'] > 0 && $last > 0 && ( $now - $last ) < $stage['every'] ) {
                    continue;
                }
                if ( null !== $stage['due'] && ! $this->{$stage['due']}() ) {
                    continue;
                }
                $id = $this->enqueueStage( $type, [], $stage['priority'] );
                if ( null !== $id ) {
                    $enqueued[]     = $type;
                    $runs[ $type ] = gmdate( 'c', $now );
                }
            } catch ( Throwable $e ) {
                $this->logger->error( 'automation', 'Stage scheduling failed: ' . $e->getMessage(), [ 'type' => $type ] );
            }
        }
        if ( [] !== $enqueued ) {
            update_option( self::OPTION_STAGE_RUNS, $runs, false );
        }
        return $enqueued;
    }

    private function evaluateDue(): bool {
        if ( ! $this->limits->allow( 'evaluations' ) ) {
            return false;
        }
        $prospects = $this->container()->get( Prospects::class );
        // Machine-parked prospects (unreachable / evaluation error) also need the stage once their retry is due.
        return [] !== $prospects->dueForEvaluation( 1 ) || [] !== EvaluateJob::retryDue( $prospects, 1 );
    }

    private function opportunitiesDue(): bool {
        return [] !== $this->container()->get( Prospects::class )->qualifiedWithoutOpportunities( 1 );
    }

    private function submitDue(): bool {
        if ( ! $this->limits->allow( 'submissions' ) ) {
            return false;
        }
        return [] !== $this->container()->get( Submissions::class )->readyToProcess( 1 );
    }

    private function outreachDue(): bool {
        if ( ! $this->limits->allow( 'outreach_emails' ) ) {
            return false;
        }
        // Only rows the send stage may actually send (active, uncapped campaign; scheduled rows only with autosend
        // on), so held-back messages do not queue a send job that does nothing on every tick. Rows left "sending"
        // by a run that died also make it due, because the send stage is what marks them failed.
        $engine = $this->container()->get( OutreachEngine::class );
        if ( $engine->hasStaleClaims() ) {
            return true;
        }
        // Outside the send window (by default weekdays 9-17, about 24 % of the week) the stage could only skip every
        // message as "outside_send_window": measured on a test copy on a Sunday, a no-op send job on each of 15 ticks
        // (an idle tick: 36 queries and 10 write queries; 22 and 3 without it). The stage is due again on the first
        // tick inside the window; nothing waits longer than before.
        if ( ! $this->container()->get( Compliance::class )->withinSendWindow() ) {
            return false;
        }
        return $engine->hasSendable();
    }

    private function monitorDue(): bool {
        if ( $this->limits->allow( 'backlink_checks' ) && [] !== $this->container()->get( Backlinks::class )->dueForCheck( 1 ) ) {
            return true;
        }
        return $this->digestDue();
    }

    /**
     * IndexNow has URLs waiting (changed posts queued by the save hooks, the first submission, or the daily
     * comparison) and may submit (production site, search engines not discouraged, no back-off running).
     */
    private function indexnowDue(): bool {
        try {
            return class_exists( IndexNow::class ) && $this->container()->get( IndexNow::class )->isDue();
        } catch ( Throwable $e ) {
            return false;
        }
    }

    /** The bundled verified opportunity data has a version that is not fully imported (or a pass is unfinished). */
    private function verifiedImportDue(): bool {
        try {
            return class_exists( VerifiedOpportunities::class ) && $this->container()->get( VerifiedOpportunities::class )->needsImport();
        } catch ( Throwable $e ) {
            return false;
        }
    }

    private function digestDue(): bool {
        try {
            if ( ! class_exists( Notifier::class ) ) {
                return false;
            }
            return (bool) $this->container()->get( Notifier::class )->digestDue();
        } catch ( Throwable $e ) {
            return false;
        }
    }

    /**
     * When automation is switched off, automatically enqueued work must not run; manual jobs stay queued.
     * The stage's last-run marker is cleared so it is re-enqueued promptly once automation is re-enabled.
     */
    private function cancelAutomaticQueued(): void {
        try {
            $queued = $this->jobs->findBy( [ 'status' => Jobs::STATUS_QUEUED ], 'id', 'ASC', 200 );
        } catch ( Throwable $e ) {
            return;
        }
        if ( [] === $queued ) {
            return;
        }
        $runs    = $this->stageRuns();
        $changed = false;
        foreach ( $queued as $job ) {
            $payload = is_array( $job['payload'] ?? null ) ? $job['payload'] : [];
            if ( ! empty( $payload['manual'] ) ) {
                continue;
            }
            try {
                $this->jobs->update(
                    (int) $job['id'],
                    [ 'status' => Jobs::STATUS_CANCELLED, 'finished_at' => gmdate( 'Y-m-d H:i:s' ), 'error' => 'Cancelled: automation disabled.' ]
                );
                unset( $runs[ (string) $job['type'] ] );
                $changed = true;
            } catch ( Throwable $e ) {
                $this->logger->error( 'automation', 'Could not cancel queued job: ' . $e->getMessage(), [ 'id' => (int) $job['id'] ] );
            }
        }
        if ( $changed ) {
            update_option( self::OPTION_STAGE_RUNS, $runs, false );
            $this->logger->info( 'automation', 'Automation is disabled; automatically queued jobs were cancelled.' );
        }
    }

    private function hasQueuedManual(): bool {
        try {
            foreach ( $this->jobs->findBy( [ 'status' => Jobs::STATUS_QUEUED ], 'id', 'ASC', 200 ) as $job ) {
                $payload = is_array( $job['payload'] ?? null ) ? $job['payload'] : [];
                if ( ! empty( $payload['manual'] ) ) {
                    return true;
                }
            }
        } catch ( Throwable $e ) {
            unset( $e );
        }
        return false;
    }

    /** @return array<string,string> type => ISO-8601 time of the last enqueue/run */
    private function stageRuns(): array {
        $runs = get_option( self::OPTION_STAGE_RUNS, [] );
        return is_array( $runs ) ? $runs : [];
    }

    private function recordStageRun( string $type ): void {
        $runs          = $this->stageRuns();
        $runs[ $type ] = gmdate( 'c' );
        update_option( self::OPTION_STAGE_RUNS, $runs, false );
    }

    /** Tick budget: the configured ceiling, never below what the stages need for one item (JobRunner::MIN_TICK_SECONDS). */
    private function maxSeconds(): float {
        return JobRunner::effectiveMaxSeconds( $this->settings );
    }

    private function container(): Container {
        return $this->runner->container();
    }

    /** The approval policy (Autopilot), built from the same settings when the container has none. */
    private function autopilot(): Autopilot {
        try {
            $svc = $this->container()->get( Autopilot::class );
            if ( $svc instanceof Autopilot ) {
                return $svc;
            }
        } catch ( Throwable $e ) {
            unset( $e );
        }
        return new Autopilot( $this->settings );
    }

    /** @return array<string,bool> */
    private function effectiveFlags(): array {
        $out = [];
        foreach ( self::FLAGS as $flag ) {
            $out[ $flag ] = $this->autopilot()->flag( $flag );
        }
        return $out;
    }
}
